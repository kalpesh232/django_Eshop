from django.urls import path
from . import views                     # import function
from store.views import home, login, signup
from .views.login import Login,user_logout
from .views.cart import Cart
from .views.check_out import CheckOut
from .views.order import OrderView
from store.middlewares.auth import auth_middleware

urlpatterns = [
    path('', home.index.as_view() ),                                      # map path to that function
    path('signup', signup.SignUp.as_view() ),
    path('login', login.Login.as_view() ),
    # path('profile', profile ),
    path('logout', user_logout),
    path('cart', Cart.as_view()),
    path('check_out', CheckOut.as_view()),
    path('orders', auth_middleware(OrderView.as_view())),
]