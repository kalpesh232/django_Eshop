from django.contrib import admin
from .models import  Product, Customer, Order
from .categori import Category                    # import model


# Register your models here.

class AdminProducts(admin.ModelAdmin):
    list_display = ['name', 'price', 'category']

class AdminCategory(admin.ModelAdmin):
    list_display = ['categoryName']

class AdminCustomer(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'phone', 'email', 'password']

admin.site.register(Product, AdminProducts)
admin.site.register(Category,AdminCategory)                        #  resister model
admin.site.register(Customer,AdminCustomer)
admin.site.register(Order)

# @staticmethod
# def get_all_products():
#     return Product.objects.all()
