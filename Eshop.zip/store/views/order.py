from django.shortcuts import render, HttpResponse, redirect
from store.models import Product, Customer, Order
from django.views import View
from django.utils.decorators import  method_decorator


class OrderView(View):
   
    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.objects.filter(customer=customer).order_by('-date')
        
        return render(request,  'orders.html' , {'orders' :  orders})
   