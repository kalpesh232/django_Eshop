from django.shortcuts import render, HttpResponse, redirect
from store.models import  Customer
from django.contrib.auth.hashers import make_password
from django.views import View

class SignUp(View):

    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password')

        form_value = {
            'fname' : fname, 
            'lname' : lname,
            'phone' : phone,
            'email' : email
        }

        error_msg = ''

        save_customer = Customer(first_name=fname, last_name=lname, phone=phone, email=email, password=password)
        error_msg =  self.validate_customer(save_customer)

        if not error_msg :
            save_customer.password =  make_password(password) 
            save_customer.save()
            # return HttpResponse('Customer Added Successfully')
            return redirect('/')
        else:
            form_data = {
                'errors' : error_msg,
                'form_values' : form_value
            }
            return render(request, 'signup.html', {'form_data':form_data})

    def validate_customer(self, save_customer):
        error_msg = ''

        if not save_customer.first_name :
             error_msg = 'First Name is Required'
        elif not save_customer.last_name :
             error_msg = 'Last Name is Required'
        elif not save_customer.phone :
             error_msg = 'Phone Number is Required'
        elif len(save_customer.phone) != 10 :
            error_msg = 'Phone Number Must be 10 digits'
        elif not save_customer.email :
            error_msg = 'Email Address is Required'
        elif Customer.objects.filter(email=save_customer.email):
            error_msg = 'Email Address Already Exist'
        elif not save_customer.password :
            error_msg = 'Password  is Required'
        elif len(save_customer.password) < 6 :
            error_msg = 'Password Must be 6 Character Long'

        return error_msg