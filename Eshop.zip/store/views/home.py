from django.shortcuts import render, HttpResponse, redirect
from store.models import Product
from store.models import Category, Customer
from django.contrib.auth import authenticate, login, logout    
from django.contrib import messages
from django.views import View


# Create your views here.

class index(View):

    def post(self, request):
        productid = request.POST.get('productid')
        print(productid)
        remove = request.POST.get('remove')
   
        cart = request.session.get('cart')
        if cart :
            quantity = cart.get(productid)
            if quantity :
                if remove:
                    if quantity <= 1 :
                        cart.pop(productid)
                    else:
                        cart[productid]=quantity-1
                else:
                    cart[productid]=quantity+1
            else:
                cart[productid]=1
        else:
            cart = {}
            cart[productid]=1

        request.session['cart'] = cart
        print('cart : ', request.session['cart'])
        return redirect('/')

    def get(self, request):
     
        # return HttpResponse('<h1>Welcome To Home Page Through Index Function</h1>')       # simple message
        # return render (request, 'index.html')
        # return render(request, 'orders/order.html')

        cart = request.session.get('cart')
        if not cart :
            request.session['cart'] = {}

        all_products = Product.objects.all()
        all_categories = Category.objects.all()

        categoryID = request.GET.get('category_id') 
        print( 'you are : ',  request.session.get('customer_email'))
        
        if categoryID :
            category_project = Product.objects.filter(category=categoryID)
            return render(request, 'index.html', {'allProducts' : category_project, 'all_categories':all_categories})
        else:
            return render(request, 'index.html', {'allProducts' : all_products, 'all_categories':all_categories})

def profile(request):
    if customer:
        return render(request, 'profile.html', {'name':customer})
    else:
        return redirect('/login')
    


           

            